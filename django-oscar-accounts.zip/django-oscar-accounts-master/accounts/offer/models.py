from django.db import models


class Range(models.Model):
    pass
