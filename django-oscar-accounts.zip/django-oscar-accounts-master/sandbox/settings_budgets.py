from settings import *

ACCOUNTS_UNIT_NAME = 'Budget'
