=========
Changelog
=========

0.3 (2013-08-13)
----------------

- Include HTML templates in package
- Dashboard templating fixes

