# -*- coding: utf-8 -*-


class ModuleNotFoundError(Exception):
    pass


class AppNotFoundError(Exception):
    pass


class ClassNotFoundError(Exception):
    pass
