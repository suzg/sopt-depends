class ImageImportError(Exception):
    pass


class IdenticalImageError(Exception):
    pass


class InvalidImageArchive(Exception):
    pass
