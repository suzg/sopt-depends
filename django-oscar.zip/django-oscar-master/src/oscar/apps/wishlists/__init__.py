default_app_config = 'oscar.apps.wishlists.config.WishlistsConfig'
