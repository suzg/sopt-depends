class ImportingError(Exception):
    pass


class CatalogueImportError(Exception):
    pass


class InvalidStockAdjustment(Exception):
    pass
