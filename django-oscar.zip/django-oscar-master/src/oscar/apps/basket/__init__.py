default_app_config = 'oscar.apps.basket.config.BasketConfig'
