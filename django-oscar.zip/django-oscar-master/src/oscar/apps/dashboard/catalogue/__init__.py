default_app_config = (
    'oscar.apps.dashboard.catalogue.config.CatalogueDashboardConfig')
