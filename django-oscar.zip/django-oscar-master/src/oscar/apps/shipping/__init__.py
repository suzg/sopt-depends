default_app_config = 'oscar.apps.shipping.config.ShippingConfig'
