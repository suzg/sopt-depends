default_app_config = 'oscar.apps.search.config.SearchConfig'
