default_app_config = 'oscar.apps.analytics.config.AnalyticsConfig'
