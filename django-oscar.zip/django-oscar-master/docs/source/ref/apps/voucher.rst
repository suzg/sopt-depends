=======
Voucher
=======

Oscar ships with broad support for vouchers, which are handled by this app.

Abstract models
---------------

.. automodule:: oscar.apps.voucher.abstract_models
    :members:

Views
-----

None.

