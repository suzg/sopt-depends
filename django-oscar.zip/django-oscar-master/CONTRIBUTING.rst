=====================
Contributing to Oscar
=====================

Thank you for wanting to contribute! You can find detailed guidance in the repository at ``docs/source/internals/contributing``, or online at:

http://django-oscar.readthedocs.org/en/latest/internals/contributing/index.html
