============
Sandbox site
============

This site is deployed there:

http://latest.oscarcommerce.com
-------------------------------

This site is used for testing the vanilla Oscar functionality, that is, Oscar
without any customisation.  It is not a demo site for clients or potential Oscar
users.  It is built automatically from the HEAD of the master branch every 20
minutes.

